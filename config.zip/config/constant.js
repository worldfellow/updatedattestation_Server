var constants = {
	// BASE_URL : "https://mu.etranscript.in/api",
	//BASE_URL: 'http://mu.etranscript.in:5000',
	BASE_URL : 'localhost:5000/',
	PORT : 5000,
	SYSTEM_TIMEZONE: 'Asia/Kolkata',
	//FILE_LOCATION:'/srv/www/attestation/',
	FILE_LOCATION:'C:/Users/info/OneDrive/Desktop/MU-Updated/updated_attestationServer/',
	Certificate_Url:'C:/Users/info/OneDrive/Desktop/MU-Updated/updated_attestationServer/',
	TMP_FILE_UPLOAD_PATH: 'public/upload/tmp/',
    PDF_VIEW :'https://mu.etranscript.in/api/',
    urlAuthString :'https://euploads.wes.org/api/v2/authenticate',
	urlFileUpload :'https://euploads.wes.org/api/v2/file',
	signedFileUrl : '/srv/www/Attestation_Server/public/signedpdf/',
	BASE_URL_SENDGRID :'http://localhost:60',
	NODE_MODULES_PATH:'C:/Users/info/OneDrive/Desktop/GUGUGUGUG/guAttestationServer/node_modules/',
	//NEW EMAIL Configurations
	SMTP_USERNAME: "uom@admissiondesk.org",
	SMTP_PASSWORD: "edulab321",
	SEND_EMAIL_FROM: "uom@admissiondesk.org",
	SEND_EMAIL_FROM_NAME: "University Of Mumbai",
	SENDGRID_API_KEY: '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',
	//SENDGRID_API_KEY: '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',
	ENV_sendgrid_Twilio: 'production',
	// HR_BASE_URL :  'https://hr.etranscript.in:6003/',
	// KC_BASE_URL :  'https://kc.etranscript.in:8081/',

	// HR_BASE_URL :  'http://localhost:6003/',  
	// KC_BASE_URL : 'http://localhost:8081/',

	

	// HR_DOC_URL :'C:/Users/Admin/Desktop/attestation/HRSERVER/public/upload/transcript/',

	// HR_TO : 'C:/Users/Admin/Desktop/attestation/Attestation_Server/public/upload/transcript/',

	
	// HR_Marklist_DOC_URL :'C:/Users/Admin/Desktop/attestation/HRSERVER/public/upload/marklist/',

	// HR_Marklist_TO : 'C:/Users/Admin/Desktop/attestation/Attestation_Server/public/upload/marklist/',



	// KC_DOC_URL :'C:/Users/Admin/Desktop/attestation/KCSERVER/public/upload/transcript/',

	// KC_TO : 'C:/Users/Admin/Desktop/attestation/Attestation_Server/public/upload/transcript/',

	// KC_Marklist_DOC_URL :'C:/Users/Admin/Desktop/attestation/KCSERVER/public/upload/marklist/',

	// KC_Marklist_TO : 'C:/Users/Admin/Desktop/attestation/Attestation_Server/public/upload/marklist/',




	
	HOST : 'sftp22.WES.quatrix.it',
	QUSERNAME : 'q5020256',
	QPASSWORD : 'Babson@7287',
	SERVERPATH : '/MU/',
	VIEW_VERIFY_EMAIL: 'verify_email',
	CLOUDCONVERTKEY : '37ghbio4CcT3N7mdKAPQNIniRg78R8EkJEMn31UQ_t3u24Uty9ab0MMByNO4euNuPXhVoa3ItJY-Vz_A1kDuyw',
	PASSPHRASE : 'P@ssw0rd'
}

module.exports = constants;
